import javax.swing._
import java.awt._
import java.awt.event._

object TemperatureConverterUI extends JFrame {
  setTitle("Temperature Converter")
  setSize(600, 200)
  setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE) 
  
  val temperatureField = new JTextField(10)
  val scaleComboBox = new JComboBox(Array("Celsius", "Fahrenheit", "Kelvin"))
  val resultLabel = new JLabel("Result will be shown here")
  
  val convertButton = new JButton("Convert")
  
  val contentPane = getContentPane
  contentPane.setLayout(new GridLayout(6, 6))
  
  contentPane.add(new JLabel("Enter the temperature:"))
  contentPane.add(temperatureField)
  contentPane.add(new JLabel("Select the scale:"))
  contentPane.add(scaleComboBox)
  contentPane.add(convertButton)
  contentPane.add(resultLabel)
  
  convertButton.addActionListener(new ActionListener() {
    def actionPerformed(e: ActionEvent): Unit = {
      val temperature = temperatureField.getText.toDouble
      val scale = scaleComboBox.getSelectedItem.toString
      
      val result = scale match {
        case "Celsius" =>
          s"$temperature°C is ${TemperatureConverter.celsiusToFahrenheit(temperature)}°F and ${TemperatureConverter.celsiusToKelvin(temperature)}K"
        case "Fahrenheit" =>
          s"$temperature°F is ${TemperatureConverter.fahrenheitToCelsius(temperature)}°C and ${TemperatureConverter.fahrenheitToKelvin(temperature)}K"
        case "Kelvin" =>
          s"$temperature K is ${TemperatureConverter.kelvinToCelsius(temperature)}°C and ${TemperatureConverter.kelvinToFahrenheit(temperature)}°F"
      }
      
      resultLabel.setText(result)
    }
  })
  
  def main(args: Array[String]): Unit = {
    SwingUtilities.invokeLater(new Runnable() {
      def run(): Unit = {
        setVisible(true)
      }
    })
  }
}

object TemperatureConverter {
  def celsiusToFahrenheit(celsius: Double): Double = {
    (celsius * 9/5) + 32
  }

  def fahrenheitToCelsius(fahrenheit: Double): Double = {
    (fahrenheit - 32) * 5/9
  }

  def celsiusToKelvin(celsius: Double): Double = {
    celsius + 273.15
  }

  def kelvinToCelsius(kelvin: Double): Double = {
    kelvin - 273.15
  }

  def fahrenheitToKelvin(fahrenheit: Double): Double = {
    celsiusToKelvin(fahrenheitToCelsius(fahrenheit))
  }

  def kelvinToFahrenheit(kelvin: Double): Double = {
    celsiusToFahrenheit(kelvinToCelsius(kelvin))
  }
}
